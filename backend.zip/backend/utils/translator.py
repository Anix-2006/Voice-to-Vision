import os

VIDEO_DIR = "static/videos"

def load_video_map():
    video_map = {}
    for file in os.listdir(VIDEO_DIR):
        name = file.split(".")[0].lower()
        video_map[name] = f"{VIDEO_DIR}/{file}"
    return video_map

video_map = load_video_map()


def translate_text_to_videos(text: str):
    words = text.lower().split()
    output_videos = []

    for word in words:
        if word in video_map:
            output_videos.append(video_map[word])
        else:
            for char in word:
                if char in video_map:
                    output_videos.append(video_map[char])

    return output_videos
