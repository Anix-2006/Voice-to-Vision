function sendText() {
    let text = document.getElementById("textInput").value;

    fetch("/translate", {
        method: "POST",
        headers: { "Content-Type": "application/json"},
        body: JSON.stringify({ text: text })
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById("resultVideo").src = data.final_video_url;
    })
    .catch(err => alert("Error: " + err));
}


// ---------------- VOICE INPUT ----------------

let recognition;

function startVoice() {
    if (!("webkitSpeechRecognition" in window)) {
        alert("Voice recognition not supported in your browser.");
        return;
    }

    recognition = new webkitSpeechRecognition();
    recognition.lang = "en-US";
    recognition.start();

    document.getElementById("voiceStatus").innerText = "Listening...";

    recognition.onresult = function(event) {
        let text = event.results[0][0].transcript;
        document.getElementById("textInput").value = text;
        document.getElementById("voiceStatus").innerText = "Captured: " + text;
    };

    recognition.onerror = function() {
        document.getElementById("voiceStatus").innerText = "Error capturing voice.";
    };

    recognition.onend = function() {
        document.getElementById("voiceStatus").innerText += " (Stopped)";
    };
}
