import os
import csv
import unicodedata
import re
from typing import List

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, HTMLResponse
from pydantic import BaseModel

from moviepy.editor import VideoFileClip, concatenate_videoclips, vfx


# ----------------------------------------------------------
# PATHS
# ----------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
VIDEOS_DIR = os.path.join(BASE_DIR, "../static/videos")
OUTPUT_DIR = os.path.join(BASE_DIR, "../output")
FRONTEND_DIR = os.path.join(BASE_DIR, "static", "web")

os.makedirs(OUTPUT_DIR, exist_ok=True)


# ----------------------------------------------------------
# FASTAPI APP
# ----------------------------------------------------------
app = FastAPI(title="ISL Translator API")

# Enable CORS for frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ----------------------------------------------------------
# STATIC FILE MOUNTS
# ----------------------------------------------------------
app.mount("/videos", StaticFiles(directory=os.path.abspath(VIDEOS_DIR)), name="videos")
app.mount("/output", StaticFiles(directory=os.path.abspath(OUTPUT_DIR)), name="output")

# Serve frontend (JS/CSS) from:  /static/*
app.mount("/static", StaticFiles(directory=FRONTEND_DIR), name="web")


# ----------------------------------------------------------
# ROOT HOMEPAGE
# ----------------------------------------------------------
@app.get("/", response_class=HTMLResponse)
def serve_homepage():
    index_path = os.path.join(FRONTEND_DIR, "index.html")
    return FileResponse(index_path)


# ----------------------------------------------------------
# LOAD MAPPING FILE
# ----------------------------------------------------------
MAPPING_CSV = os.path.join(BASE_DIR, "mapping.csv")
mapping = {}

if os.path.exists(MAPPING_CSV):
    with open(MAPPING_CSV, newline='', encoding="utf-8") as f:
        reader = csv.reader(f)
        for row in reader:
            if len(row) >= 2:
                token = row[0].strip().lower()
                filename = row[1].strip()
                mapping[token] = filename


# ----------------------------------------------------------
# TEXT NORMALIZATION
# ----------------------------------------------------------
def normalize_text(text: str) -> str:
    text = unicodedata.normalize("NFKC", text)
    text = text.lower()
    text = re.sub(r"[^\w\s]", " ", text)  # remove punctuation
    text = re.sub(r"\s+", " ", text).strip()
    return text


# ----------------------------------------------------------
# SAFE VIDEO MERGING
# ----------------------------------------------------------
def stitch_videos(video_paths, output_path):
    safe_clips = []

    for path in video_paths:
        if not os.path.exists(path) or os.path.getsize(path) == 0:
            print("⚠ Skipping missing file:", path)
            continue

        try:
            clip = VideoFileClip(path).set_fps(24)

            # Extend very short clips
            if clip.duration < 0.5:
                clip = clip.fx(vfx.freeze, t=0, total_duration=0.5)

            clip = clip.resize((1280, 720))
            safe_clips.append(clip)

        except Exception as e:
            print("❌ Error loading video:", path, e)

    if not safe_clips:
        raise Exception("No valid clips available to merge")

    final = concatenate_videoclips(safe_clips, method="compose")
    final.write_videofile(output_path, codec="libx264", audio=False, fps=24)

    for c in safe_clips:
        c.close()

    return output_path


# ----------------------------------------------------------
# REQUEST / RESPONSE MODELS
# ----------------------------------------------------------
class TranslateRequest(BaseModel):
    text: str


class TranslateResponse(BaseModel):
    final_video_url: str
    used_tokens: List[str]
    missing: List[str]


# ----------------------------------------------------------
# TRANSLATE ENDPOINT
# ----------------------------------------------------------
@app.post("/translate", response_model=TranslateResponse)
def translate(req: TranslateRequest):
    text_norm = normalize_text(req.text)
    words = text_norm.split()

    video_files = []
    used = []
    missing = []

    for word in words:
        if word in mapping:
            video_files.append(os.path.join(VIDEOS_DIR, mapping[word]))
            used.append(word)
        else:
            # Spell out letters as fallback
            for ch in word:
                if ch in mapping:
                    video_files.append(os.path.join(VIDEOS_DIR, mapping[ch]))
                    used.append(ch)
                else:
                    missing.append(ch)

    if not video_files:
        raise HTTPException(status_code=400, detail="No matching signs found")

    output_path = os.path.join(OUTPUT_DIR, "final_output.mp4")

    # Build video
    stitch_videos(video_files, output_path)

    return TranslateResponse(
        final_video_url="/output/final_output.mp4",
        used_tokens=used,
        missing=missing
    )
