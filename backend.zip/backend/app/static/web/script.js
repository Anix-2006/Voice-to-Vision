function sendText() {
    const text = document.getElementById("textInput").value;

    fetch("/translate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text })
    })
    .then(r => r.json())
    .then(data => {
        document.getElementById("resultVideo").src = data.final_video_url;
    });
}

function startVoice() {
    const recognition = new webkitSpeechRecognition();
    recognition.lang = "en-IN";
    recognition.start();
    
    document.getElementById("voiceStatus").innerText = "Listening...";

    recognition.onresult = function(event) {
        const speech = event.results[0][0].transcript;
        document.getElementById("textInput").value = speech;
        document.getElementById("voiceStatus").innerText = "Voice captured!";
    };
}
